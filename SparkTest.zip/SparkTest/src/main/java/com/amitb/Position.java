package com.amitb;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Position implements Serializable{
	private static final long serialVersionUID = 1L;

	private String pid;
	
	List<Fs> fs = new ArrayList<>();

	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

	public List<Fs> getFs() {
		return fs;
	}

	public void setFs(List<Fs> fs) {
		this.fs = fs;
	}

	
	
}
