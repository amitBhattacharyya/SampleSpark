package com.amitb;

import java.io.Serializable;

public class Fs implements Serializable{
	
	public Fs() {
		// TODO Auto-generated constructor stub
	}
	
	private String col1, col2;

	public String getCol1() {
		return col1;
	}

	public void setCol1(String col1) {
		this.col1 = col1;
	}

	public String getCol2() {
		return col2;
	}

	public void setCol2(String col2) {
		this.col2 = col2;
	}

	public Fs(String col1, String col2) {
		super();
		this.col1 = col1;
		this.col2 = col2;
	}
	
	

}
