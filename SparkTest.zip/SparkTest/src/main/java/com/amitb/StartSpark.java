package com.amitb;

import java.util.ArrayList;
import java.util.List;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.SparkSession;

public class StartSpark {

	public static void main(String[] args) {
		SparkSession spark = SparkSession.builder().appName("Spark Pi")
//				.config("parquet.enable.dictionary","true")
				.config("spark.sql.parquet.compression.codec", "gzip")
				.config("spark.sql.inMemoryColumnarStorage.compressed", true)
				.config("spark.sql.inMemoryColumnarStorage.batchSize", 50000)
//				.config("spark.sql.parquet.aggregatePushdown", true)
//				.config("spark.sql.parquet.recordLevelFilter.enabled", true)
//				.config("spark.sql.parquet.columnarReaderBatchSize", 1024*50)
				.master("local[2]").getOrCreate();

//		for(int i=1; i<100; i++) {			
//			String date = extracted(i);
//			System.out.println("============================================");
//			System.out.println(new Date() + " started for " + date);
//			write15Millionrecords(spark, date);
//			System.out.println(new Date() + " ended  for " + date);
//			System.out.println("============================================");
//			
//		}

		List<Position> p = new ArrayList<>();

		for (int i = 0; i < 100; i++) {
			Position p1 = new Position();
			p1.setPid("" + System.currentTimeMillis());
			p1.getFs().add(new Fs("A" + i, "B" + i));
			p1.getFs().add(new Fs("A" + i * 2, "B" + i * 3));
			p.add(p1);
		}

		Dataset<Position> createDataset = spark.createDataset(p, Encoders.bean(Position.class));

		createDataset.show();

		// readPartitioned(spark);

		spark.close();

	}

}
